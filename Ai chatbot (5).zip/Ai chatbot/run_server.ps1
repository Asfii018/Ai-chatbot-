# Agile Chatbot Server Startup Script
# Run this script to start the FastAPI server

Write-Host "Starting Agile Chatbot API Server..." -ForegroundColor Green
Write-Host ""

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Start the server
python -m uvicorn src.serve_api:app --reload --host 127.0.0.1 --port 8000

