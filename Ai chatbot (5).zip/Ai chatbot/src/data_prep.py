import os
import pandas as pd

#  Correct dataset folder path
base = r"D:\Ai chatbot\Data\Agile Scrum Dataset\Finalized Datasets for Meso Project"

# Define file paths
sprints_file = os.path.join(base, "MESO Issue Summary 370.csv")
issues_file = os.path.join(base, "MESO Sprint 96.csv")
issues_summary_file = os.path.join(base, "Mesos Stories 176.csv")

print(" Dataset path:", base)

#  Load each CSV
sprints_df = pd.read_csv(sprints_file)
issues_df = pd.read_csv(issues_file)
issues_summary_df = pd.read_csv(issues_summary_file)

print("\n Loaded data successfully!")
print(f"Sprints shape: {sprints_df.shape}")
print(f"Issues shape: {issues_df.shape}")
print(f"Issues Summary shape: {issues_summary_df.shape}")

#  Clean column names (remove spaces)
sprints_df.columns = sprints_df.columns.str.strip().str.replace(" ", "_")
issues_df.columns = issues_df.columns.str.strip().str.replace(" ", "_")
issues_summary_df.columns = issues_summary_df.columns.str.strip().str.replace(" ", "_")

#  Save cleaned CSVs
output_dir = "data"
os.makedirs(output_dir, exist_ok=True)
sprints_df.to_csv(os.path.join(output_dir, "MESO_sprints.csv"), index=False)
issues_df.to_csv(os.path.join(output_dir, "MESO_issues.csv"), index=False)
issues_summary_df.to_csv(os.path.join(output_dir, "MESO_issues_summary.csv"), index=False)

print("\n Done! Saved cleaned data to:")
print("   → data/MESO_sprints.csv")
print("   → data/MESO_issues.csv")
print("   → data/MESO_issues_summary.csv")
