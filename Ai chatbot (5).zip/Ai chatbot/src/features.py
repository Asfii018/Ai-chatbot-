import os
import pandas as pd
import numpy as np

# ======================================
# Load cleaned data
# ======================================
sprints_path = "data/MESO_sprints.csv"
issues_path = "data/MESO_issues.csv"
issues_summary_path = "data/MESO_issues_summary.csv"

sprints = pd.read_csv(sprints_path)
issues = pd.read_csv(issues_path)
issues_summary = pd.read_csv(issues_summary_path)

print(" Loaded datasets:")
print(f"   Sprints: {sprints.shape}")
print(f"   Issues: {issues.shape}")
print(f"   Issues Summary: {issues_summary.shape}")

# ======================================
# Rename sprint columns to standard form
# ======================================
rename_map = {
    'total': 'PlannedStoryPoints',
    'completedIssuesEstimateSum': 'CompletedStoryPoints',
    'sprintId': 'SprintID',
    'sprintStartDate': 'StartDate',
    'sprintEndDate': 'EndDate',
    'NoOfDevelopers': 'Developers',
    'SprintLength': 'SprintDurationDays'
}
sprints.rename(columns=rename_map, inplace=True)

# ======================================
# Clean up and convert data types
# ======================================
date_cols = [c for c in sprints.columns if "Date" in c or "date" in c]
for col in date_cols:
    try:
        sprints[col] = pd.to_datetime(sprints[col], errors="coerce", infer_datetime_format=True)
    except Exception:
        pass

sprints = sprints.fillna(0)

# ======================================
# Feature Engineering
# ======================================
def build_sprint_features(df, issues_df):
    df = df.copy()

    # Convert numeric columns safely
    for c in ["PlannedStoryPoints", "CompletedStoryPoints", "SprintDurationDays"]:
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0)

    # --- Target variable: Delayed or not
    df['Delayed'] = (df['CompletedStoryPoints'] < df['PlannedStoryPoints']).astype(int)

    # --- Velocity
    df['Velocity'] = df['CompletedStoryPoints'] / df['SprintDurationDays'].replace(0, np.nan)

    # --- Completion ratio and uncompleted points
    df['Completion_Ratio'] = df['CompletedStoryPoints'] / df['PlannedStoryPoints'].replace(0, np.nan)
    df['Uncompleted_Points'] = df['PlannedStoryPoints'] - df['CompletedStoryPoints']

    # --- Developer productivity
    df['Points_per_Developer'] = df['CompletedStoryPoints'] / df['Developers'].replace(0, np.nan)
    df['Issues_per_Developer'] = df['completedIssuesCount'] / df['Developers'].replace(0, np.nan)

    # --- Optional: average issue story points (if Issues.csv has 'StoryPoints')
    if 'StoryPoints' in issues_df.columns and 'SprintID' in issues_df.columns:
        avg_story = issues_df.groupby('SprintID', as_index=False)['StoryPoints'].mean().rename(columns={'StoryPoints':'Avg_Issue_StoryPoints'})
        df = pd.merge(df, avg_story, on='SprintID', how='left')
    else:
        df['Avg_Issue_StoryPoints'] = 0

    # Replace inf and NaN
    df = df.replace([np.inf, -np.inf], np.nan).fillna(0)

    # --- Select final features
    feature_cols = [
        'PlannedStoryPoints', 'CompletedStoryPoints', 'Velocity',
        'Completion_Ratio', 'Uncompleted_Points', 'Developers', 'Points_per_Developer',
        'Issues_per_Developer', 'SprintDurationDays', 'Delayed'
    ]

    final = df[feature_cols]
    print("\n Feature engineering complete!")
    print(f"   → Final feature matrix shape: {final.shape}")

    return final

# ======================================
# Run feature building
# ======================================
features = build_sprint_features(sprints, issues)

# Save
os.makedirs("data", exist_ok=True)
features.to_csv("data/sprint_features.csv", index=False)

print("\n Saved feature file: data/sprint_features.csv")
