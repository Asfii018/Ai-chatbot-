from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import os
import joblib
import xgboost as xgb
import numpy as np
import shap
import tensorflow as tf
from tensorflow.keras.models import load_model

# ==============================
# Load Models
# ==============================
rf_model = joblib.load("models/random_forest_model.joblib")

xgb_model = xgb.XGBClassifier()
xgb_model.load_model("models/xgboost_model.json")

# Optional: LSTM model (may fail due to version compatibility)
try:
    lstm_model = load_model("models/lstm_model.h5")
    print("LSTM model loaded successfully.")
except Exception as e:
    lstm_model = None
    print(f"LSTM model could not be loaded: {e}")
    print("Continuing without LSTM model (RF and XGBoost still available).")

# Optional: Scaler used for normalization (must be saved during training)
try:
    scaler = joblib.load("models/scaler.joblib")
    print("Scaler loaded successfully.")
except Exception as e:
    scaler = None
    print(f"No scaler found — predictions may be inaccurate: {e}")
    print("Note: Models were trained on scaled data. Please retrain to save the scaler.")

# ==============================
# FastAPI setup
# ==============================
app = FastAPI(
    title="Agile Chatbot API",
    description="Predicts Sprint Delays & Risks using ML and LSTM models",
    version="2.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # allow all for local testing
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files (HTML, CSS, JS) from the web directory
web_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "web")
if os.path.exists(web_dir):
    app.mount("/web", StaticFiles(directory=web_dir, html=True), name="web")
    # Serve index.html at root
    @app.get("/")
    async def read_root():
        from fastapi.responses import FileResponse
        index_path = os.path.join(web_dir, "index.html")
        if os.path.exists(index_path):
            return FileResponse(index_path)
        return {"message": " Agile Chatbot API v2 is running!"}

feature_names = [
    "PlannedStoryPoints", "CompletedStoryPoints", "Velocity",
    "Completion_Ratio", "Uncompleted_Points", "Developers",
    "Points_per_Developer", "SprintDurationDays", "Points_per_Day"
]

VELOCITY_MIN = 0.0
VELOCITY_MAX = 10.0

# ==============================
# Request Schema
# ==============================
class SprintData(BaseModel):
    PlannedStoryPoints: float
    CompletedStoryPoints: float
    Velocity: float
    Completion_Ratio: float
    Uncompleted_Points: float
    Developers: int
    SprintDurationDays: int
    model: str = "rf"   # Default model → rf / xgb / lstm

# ==============================
# Predict Endpoint
# ==============================
@app.post("/predict_delay")
async def predict_delay(request: Request):
    """
    Predict sprint delay probability using chosen model.
    """
    try:
        data = await request.json()
        print("\n Incoming data:", data)

        # --- Step 1: Extract model choice ---
        model_choice = data.get("model", "rf").lower()

        # --- Step 2: Prepare Input ---
        # Extract basic features first
        planned_points = float(data.get("PlannedStoryPoints", 0))
        developers = float(data.get("Developers", 1))  # avoid division by zero
        duration = float(data.get("SprintDurationDays", 1))  # avoid division by zero

        # Extract features in the correct order, handling missing values properly
        feature_values = []
        for f in feature_names:
            if f == "Points_per_Developer":
                val = planned_points / developers if developers > 0 else 0.0
            elif f == "Points_per_Day":
                val = planned_points / duration if duration > 0 else 0.0
            else:
                val = data.get(f)
                if val is None:
                    val = 0.0
                else:
                    try:
                        val = float(val)
                    except (ValueError, TypeError):
                        val = 0.0

            if f == "Velocity":
                if val < VELOCITY_MIN or val > VELOCITY_MAX:
                    raise HTTPException(
                        status_code=422,
                        detail=f"Velocity must be between {VELOCITY_MIN} and {VELOCITY_MAX}. Received {val}."
                    )

            feature_values.append(val)
        
        X_raw = np.array([feature_values], dtype=float)
        X_raw = np.nan_to_num(X_raw)
        print(f" DEBUG: Raw input vector (before scaling): {X_raw}")
        print(f" DEBUG: Feature values: {dict(zip(feature_names, X_raw[0]))}")
        
        # Apply scaler if available
        if scaler is not None:
            X = scaler.transform(X_raw)
            print(f" DEBUG: Scaled input vector: {X}")
        else:
            X = X_raw
            print(" DEBUG: No scaler applied (using raw values)")
        
        print(" Cleaned input vector (X):", X)

        # --- Step 3: Predict using selected model ---
        if model_choice == "rf":
            proba_result = rf_model.predict_proba(X)
            print(f" DEBUG: RF predict_proba shape: {proba_result.shape}, values: {proba_result}")
            prob = float(proba_result[0][1])
            model_used = "Random Forest"

        elif model_choice == "xgb":
            proba_result = xgb_model.predict_proba(X)
            print(f" DEBUG: XGB predict_proba shape: {proba_result.shape}, values: {proba_result}")
            prob = float(proba_result[0][1])
            model_used = "XGBoost"

        elif model_choice == "lstm":
            if lstm_model is None:
                raise HTTPException(
                    status_code=503, 
                    detail="LSTM model is not available. Please use 'rf' or 'xgb' model instead."
                )
            X_lstm = np.expand_dims(X, axis=1)
            proba_result = lstm_model.predict(X_lstm, verbose=0)
            print(f" DEBUG: LSTM predict shape: {proba_result.shape}, values: {proba_result}")
            prob = float(proba_result[0][1])
            model_used = "LSTM Neural Network"

        else:
            raise ValueError(f"Unknown model: {model_choice}")

        print(f" DEBUG: Raw probability value: {prob}")

        # --- Step 4: Validate probability ---
        if np.isnan(prob) or np.isinf(prob):
            print("Invalid probability detected, resetting to 0.0")
            prob = 0.0

        # --- Step 5: Explain important features (Tree models only) ---
        important_feats = []
        if model_choice in ["rf", "xgb"]:
            try:
                explainer = shap.TreeExplainer(rf_model if model_choice == "rf" else xgb_model)
                shap_values = explainer.shap_values(X)

                print("\n================ SHAP DEBUG ================")
                print(f"Type: {type(shap_values)}, shape: {getattr(shap_values, 'shape', None)}")
                print("===========================================\n")

                # Handle SHAP formats robustly
                if isinstance(shap_values, list):
                    # TreeExplainer for RF usually returns list [class0, class1]
                    shap_arr = np.abs(shap_values[1][0])
                elif isinstance(shap_values, np.ndarray):
                    if shap_values.ndim == 3:
                        shap_arr = np.abs(shap_values[0, :, -1])
                    elif shap_values.ndim == 2:
                        shap_arr = np.abs(shap_values[0])
                    else:
                        shap_arr = np.abs(shap_values).ravel()
                else:
                    shap_arr = np.zeros(len(feature_names))

                shap_arr = np.nan_to_num(np.ravel(shap_arr))
                top_idx = np.argsort(shap_arr)[-3:][::-1]
                important_feats = [feature_names[int(i)] for i in top_idx]

            except Exception as shap_err:
                print(f" SHAP computation failed: {shap_err}")
                important_feats = ["Velocity", "Completion_Ratio", "Developers"]

        else:
            # Fallback for LSTM (no SHAP)
            important_feats = ["Velocity", "Completion_Ratio", "Developers"]

        # --- Step 6: Build human-readable summary ---
        summary = (
            f"This sprint has a {prob*100:.1f}% chance of delay using {model_used}. "
            f"Key factors: {', '.join(important_feats)}."
        )

        print(" Prediction summary:", summary)

        # --- Step 7: Return result ---
        return {
            "DelayProbability": float(prob),
            "Summary": summary,
            "ModelUsed": model_used
        }

    except Exception as e:
        print(f" ERROR: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Root endpoint is now defined above to serve index.html
