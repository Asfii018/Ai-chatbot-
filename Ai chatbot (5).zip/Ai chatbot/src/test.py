from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, HTTPException, Request
import joblib
import xgboost as xgb
import numpy as np
import pandas as pd
import shap

# ==============================
# Load models
# ==============================
rf_model = joblib.load("models/random_forest_model.joblib")
xgb_model = xgb.XGBClassifier()
xgb_model.load_model("models/xgboost_model.json")

# Preload SHAP explainer for RandomForest
explainer = shap.TreeExplainer(rf_model)

# ==============================
# FastAPI setup
# ==============================
app = FastAPI(
    title="Agile Chatbot API",
    description="Predicts Sprint Delays & Risks using ML models",
    version="1.0"
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # allow all for local testing
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# ==============================
# Request schema
# ==============================
class SprintData(BaseModel):
    PlannedStoryPoints: float
    CompletedStoryPoints: float
    Velocity: float
    Completion_Ratio: float
    Uncompleted_Points: float
    Developers: int
    Points_per_Developer: float
    Issues_per_Developer: float
    SprintDurationDays: int

# ==============================
# Helper: predict delay
# ==============================
@app.post("/predict_delay")
def predict_delay(data: SprintData):
    print(" Received data:", data.dict())

    try:
        X = np.array([[data.PlannedStoryPoints, data.CompletedStoryPoints, data.Velocity,
                       data.Completion_Ratio, data.Uncompleted_Points, data.Developers,
                       data.Points_per_Developer, data.Issues_per_Developer, data.SprintDurationDays]])

        prob = float(rf_model.predict_proba(X)[0][1])

        importances = rf_model.feature_importances_
        important_feats = np.argsort(importances)[-3:]
        important_feats = [str(i) for i in important_feats]

        summary = f"This sprint has a {prob*100:.1f}% chance of delay. Key factors: {', '.join(important_feats)}."

        return {"DelayProbability": prob, "Summary": summary}

    except Exception as e:
        print(" ERROR:", e)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/")
def root():
    return {"message": "Agile Chatbot API is running!"}

