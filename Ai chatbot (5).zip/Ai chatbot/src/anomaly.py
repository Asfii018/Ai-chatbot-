import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
import joblib
import os

def detect_anomalies(features_path="data/sprint_features.csv", save_path="models/anomaly_model.joblib"):
    print(" Loading features for anomaly detection...")
    df = pd.read_csv(features_path)
    if 'Delayed' in df.columns:
        X = df.drop(columns=['Delayed'])
    else:
        X = df.copy()

    print(" Data shape for anomaly detection:", X.shape)

    model = IsolationForest(
        contamination=0.15,  # assume ~15% sprints are risky
        n_estimators=200,
        random_state=42
    )
    model.fit(X)

    # Predict anomalies (-1 = anomaly, 1 = normal)
    df['AnomalyFlag'] = model.predict(X)
    df['RiskScore'] = model.decision_function(X)
    df['AnomalyFlag'] = df['AnomalyFlag'].apply(lambda x: 1 if x == -1 else 0)

    # Save model
    os.makedirs("models", exist_ok=True)
    joblib.dump(model, save_path)

    print(" Anomaly model trained and saved at:", save_path)
    print(df[['AnomalyFlag', 'RiskScore']].head())

    # Save predictions
    df.to_csv("data/sprint_anomaly_scores.csv", index=False)
    print(" Saved anomaly results → data/sprint_anomaly_scores.csv")

if __name__ == "__main__":
    detect_anomalies()
