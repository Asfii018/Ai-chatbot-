import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb
import joblib
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.utils import to_categorical

# ======================================
# Load features
# ======================================
features_path = "data/sprint_features.csv"
df = pd.read_csv(features_path)

print("Loaded feature dataset:", df.shape)

# ======================================
# Separate features and target
# ======================================
if 'Delayed' not in df.columns:
    raise ValueError("Error: No 'Delayed' column found in data/sprint_features.csv")

# Define feature order explicitly to match serve_api.py
feature_names = [
    "PlannedStoryPoints", "CompletedStoryPoints", "Velocity",
    "Completion_Ratio", "Uncompleted_Points", "Developers",
    "Points_per_Developer", "SprintDurationDays"
]

# Ensure all required features exist
missing_features = [f for f in feature_names if f not in df.columns]
if missing_features:
    raise ValueError(f"Error: Missing required features: {missing_features}")

# Extract features in the correct order
X = df[feature_names].copy()

# Calculate derived feature
X['Points_per_Day'] = X['PlannedStoryPoints'] / X['SprintDurationDays'].replace(0, 1)

# Add to feature names
feature_names.append('Points_per_Day')

y = df['Delayed']

print(f"Feature order: {list(X.columns)}")

# Normalize numeric features for LSTM
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

print(f"Training samples: {len(X_train)}, Testing samples: {len(X_test)}")

# ======================================
# 1️⃣ Random Forest Model
# ======================================
print("\nTraining Random Forest...")
rf = RandomForestClassifier(
    n_estimators=200,
    max_depth=10,
    random_state=42,
    class_weight="balanced"
)
rf.fit(X_train, y_train)
y_pred_rf = rf.predict(X_test)
rf_acc = accuracy_score(y_test, y_pred_rf)
print(f"Random Forest Accuracy: {rf_acc:.3f}")

# Save model and scaler
os.makedirs("models", exist_ok=True)
rf_model_path = "models/random_forest_model.joblib"
joblib.dump(rf, rf_model_path)
print(f"Saved Random Forest model -> {rf_model_path}")

# Save scaler (critical for consistent predictions)
scaler_path = "models/scaler.joblib"
joblib.dump(scaler, scaler_path)
print(f"Saved scaler -> {scaler_path}")

# ======================================
# 2️⃣ XGBoost Model
# ======================================
print("\nTraining XGBoost...")
xgb_model = xgb.XGBClassifier(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    eval_metric="logloss"
)
xgb_model.fit(X_train, y_train)
y_pred_xgb = xgb_model.predict(X_test)
xgb_acc = accuracy_score(y_test, y_pred_xgb)
print(f"XGBoost Accuracy: {xgb_acc:.3f}")

xgb_model_path = "models/xgboost_model.json"
xgb_model.save_model(xgb_model_path)
print(f"Saved XGBoost model -> {xgb_model_path}")

# ======================================
# 3️⃣ LSTM Model
# ======================================
print("\nTraining LSTM Deep Learning Model...")

# Reshape input to (samples, timesteps, features)
# Each row is treated as a sequence of length=1 for LSTM input
X_train_lstm = np.expand_dims(X_train, axis=1)
X_test_lstm = np.expand_dims(X_test, axis=1)

# One-hot encode target
y_train_cat = to_categorical(y_train)
y_test_cat = to_categorical(y_test)

lstm_model = Sequential([
    LSTM(64, input_shape=(X_train_lstm.shape[1], X_train_lstm.shape[2]), return_sequences=False),
    Dropout(0.3),
    Dense(32, activation='relu'),
    Dropout(0.2),
    Dense(y_train_cat.shape[1], activation='softmax')
])

lstm_model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

history = lstm_model.fit(
    X_train_lstm, y_train_cat,
    validation_data=(X_test_lstm, y_test_cat),
    epochs=40,
    batch_size=8,
    verbose=1
)

# Evaluate LSTM
loss, lstm_acc = lstm_model.evaluate(X_test_lstm, y_test_cat)
print(f"LSTM Accuracy: {lstm_acc:.3f}")

# Save model
lstm_path = "models/lstm_model.h5"
lstm_model.save(lstm_path)
print(f"Saved LSTM model -> {lstm_path}")

# ======================================
# Compare Results
# ======================================
labels = ["Random Forest", "XGBoost", "LSTM"]
accuracies = [rf_acc, xgb_acc, lstm_acc]

plt.bar(labels, accuracies, color=["green", "orange", "purple"])
plt.ylabel("Accuracy")
plt.title("Model Comparison: Sprint Delay Prediction")
plt.ylim(0, 1)
plt.show()

print("\nTraining complete! All models saved in the 'models' folder.")
