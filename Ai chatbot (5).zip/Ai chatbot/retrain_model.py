"""
Retrain the Random Forest model to be more sensitive to Velocity and other features.
This script creates synthetic training data and trains a new model.
"""

import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# Create synthetic training data with realistic patterns
np.random.seed(42)

n_samples = 500

# Generate features
PlannedStoryPoints = np.random.uniform(20, 100, n_samples)
CompletedStoryPoints = np.random.uniform(10, 100, n_samples)
Velocity = np.random.uniform(1, 10, n_samples)
Developers = np.random.randint(1, 15, n_samples)
SprintDurationDays = np.random.randint(7, 30, n_samples)

# Ensure logical relationships
CompletedStoryPoints = np.minimum(CompletedStoryPoints, PlannedStoryPoints)

# Calculate derived features
Completion_Ratio = CompletedStoryPoints / np.maximum(PlannedStoryPoints, 1)
Uncompleted_Points = PlannedStoryPoints - CompletedStoryPoints
Points_per_Developer = PlannedStoryPoints / np.maximum(Developers, 1)
Points_per_Day = PlannedStoryPoints / np.maximum(SprintDurationDays, 1)

# Create target: Delay probability based on realistic patterns
# Delay is MORE likely when:
#   - Low velocity
#   - Low completion ratio
#   - High points per developer
#   - High uncompleted points
#   - Few developers
#   - Short duration

delay_prob = (
    (1 - Velocity / 10) * 0.3 +  # Lower velocity = more delays
    (1 - Completion_Ratio) * 0.3 +  # Lower completion = more delays
    (Points_per_Developer / 20) * 0.2 +  # More work per dev = more delays
    (1 - Developers / 15) * 0.2  # Fewer developers = more delays
)

# Add some noise and convert to binary
delay_prob = np.clip(delay_prob + np.random.normal(0, 0.1, n_samples), 0, 1)
Delay = (delay_prob > 0.5).astype(int)

# Create DataFrame
X = pd.DataFrame({
    'PlannedStoryPoints': PlannedStoryPoints,
    'CompletedStoryPoints': CompletedStoryPoints,
    'Velocity': Velocity,
    'Completion_Ratio': Completion_Ratio,
    'Uncompleted_Points': Uncompleted_Points,
    'Developers': Developers,
    'Points_per_Developer': Points_per_Developer,
    'SprintDurationDays': SprintDurationDays,
    'Points_per_Day': Points_per_Day
})

y = Delay

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train Random Forest
print("Training Random Forest model...")
rf_model = RandomForestClassifier(
    n_estimators=100,
    max_depth=10,
    min_samples_split=5,
    min_samples_leaf=2,
    random_state=42,
    n_jobs=-1
)

rf_model.fit(X_train_scaled, y_train)

# Evaluate
train_score = rf_model.score(X_train_scaled, y_train)
test_score = rf_model.score(X_test_scaled, y_test)

print(f"\nModel Performance:")
print(f"  Training Accuracy: {train_score:.3f}")
print(f"  Testing Accuracy: {test_score:.3f}")

# Feature importance
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': rf_model.feature_importances_
}).sort_values('importance', ascending=False)

print(f"\nFeature Importance:")
for idx, row in feature_importance.iterrows():
    print(f"  {row['feature']:25s}: {row['importance']:.4f}")

# Save model and scaler
print("\nSaving models...")
joblib.dump(rf_model, "models/random_forest_model.joblib")
joblib.dump(scaler, "models/scaler.joblib")

print("✅ Model training complete!")

# Test with different velocities
print("\n" + "="*60)
print("TESTING: Velocity sensitivity")
print("="*60)

test_cases = [
    {"PlannedStoryPoints": 40, "CompletedStoryPoints": 35, "Velocity": 2.0, 
     "Completion_Ratio": 0.875, "Uncompleted_Points": 5, "Developers": 5,
     "Points_per_Developer": 8.0, "SprintDurationDays": 14, "Points_per_Day": 2.86},
    
    {"PlannedStoryPoints": 40, "CompletedStoryPoints": 35, "Velocity": 5.0,
     "Completion_Ratio": 0.875, "Uncompleted_Points": 5, "Developers": 5,
     "Points_per_Developer": 8.0, "SprintDurationDays": 14, "Points_per_Day": 2.86},
    
    {"PlannedStoryPoints": 40, "CompletedStoryPoints": 35, "Velocity": 9.0,
     "Completion_Ratio": 0.875, "Uncompleted_Points": 5, "Developers": 5,
     "Points_per_Developer": 8.0, "SprintDurationDays": 14, "Points_per_Day": 2.86},
]

for i, case in enumerate(test_cases, 1):
    X_test_sample = pd.DataFrame([case])
    X_test_scaled_sample = scaler.transform(X_test_sample)
    prob = rf_model.predict_proba(X_test_scaled_sample)[0][1]
    print(f"  Velocity {case['Velocity']:.1f} -> {prob*100:.1f}% delay probability")

print("\n" + "="*60)
